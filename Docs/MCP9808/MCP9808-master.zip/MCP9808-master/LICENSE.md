# Arduino Library for Microchip MCP9808 Temperature Sensor #
https://github.com/JChristensen/MCP9808  
LICENSE file  
Jack Christensen Jun 2015  

![CC BY-SA](http://mirrors.creativecommons.org/presskit/buttons/88x31/png/by-sa.png)
## CC BY-SA ##
"Arduino Library for Microchip MCP9808 Temperature Sensor" by Jack Christensen is licensed under [CC BY-SA 4.0](http://creativecommons.org/licenses/by-sa/4.0/).