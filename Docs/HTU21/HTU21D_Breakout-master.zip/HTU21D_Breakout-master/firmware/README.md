SparkFun HTU21D Firmware
===================================

* **HTU21D_SimpleSketch** - Arduino simple sketch example. See video [here](https://youtu.be/HfNsybUKU6U). 
* **SparkFun_HTU21D_Example** - Arduino example sketch for getting started. No library required. 


